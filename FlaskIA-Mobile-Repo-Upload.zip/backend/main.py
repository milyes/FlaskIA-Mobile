
from flask import Flask, render_template, request, jsonify
import logging
import openai
import os

# Configuration du logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Configuration OpenAI (clé à définir)
openai.api_key = os.getenv("OPENAI_API_KEY")

from flask_talisman import Talisman
app = Flask(__name__)
Talisman(app)

# Dossier de logs
if not os.path.exists("logs"):
    os.makedirs("logs")

# Fichier de logs
file_handler = logging.FileHandler("logs/flask.log")
file_handler.setLevel(logging.INFO)
formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

@app.route('/')
def accueil():
    logger.info("Page d'accueil visitée")
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat_ia():
    data = request.get_json()
    message = data.get('message', '')
    logger.info(f"Message reçu : {message}")
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": message}]
        )
        reply = response.choices[0].message.content.strip()
        return jsonify({'reply': reply})
    except Exception as e:
        logger.error(f"Erreur lors de la génération IA : {e}")
        return jsonify({'error': 'Erreur IA'}), 500

@app.errorhandler(404)
def page_non_trouvee(error):
    logger.error(f'Page non trouvée: {error}')
    return render_template('index.html', error="Page non trouvée. Retournez à l'accueil."), 404

@app.errorhandler(500)
def erreur_serveur(error):
    logger.error(f'Erreur serveur: {error}')
    return render_template('index.html', error="Erreur serveur. Veuillez réessayer plus tard."), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
